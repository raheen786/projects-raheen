package org.pro;

public class Snippet {
	  PrintWriter out=response.getWriter();
			
			  response.setContentType("text/html");
			  
			  int num1=Integer.parseInt(request.getParameter("n1"));
}

