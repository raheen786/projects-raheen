package org.pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class contact3ctl
 */
@WebServlet("/contact3ctl")
public class contact3ctl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public contact3ctl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Connection cn;
		Statement smt;
		ResultSet rs;
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
            cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			
			rs=smt.executeQuery("select * from contact");
			
			out.print("<table border=1");
			while(rs.next())
			{
				out.print("<tr><td>"+rs.getString("id")+"</td><td>"+rs.getString("name")+"</td><td>"+rs.getString("contactno")+"</td></tr>");
			}
			out.print("</table>");
			
			rs.close();
			smt.close();
			cn.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
