package package2;

import java.util.ArrayList;
import java.util.Scanner;


class colors1
{
	ArrayList list;
	colors1()
	{
		list=new ArrayList();
	}
	public void add(String item)
	{
		list.add(item);
	}
	public void remove(int index)
	{
		list.remove(index);
	}
	public void update(int pos,String item)
	{
		list.set(pos, item);
	}
	public void display()
	{
		for(Object name :list)
		{
			System.out.println(name.toString());
		}
	}
}


public class projects9 {

	public static void main(String[] args) {
        colors1 s=new colors1();
		
		Scanner s1=new Scanner(System.in);
		String name1;
		int pos;
		
		s.add("red");
		s.add("blue");
		s.add("pink");
		s.add("violet");
		s.add("white");
		
		System.out.println("List of colors :");
		s.display();
		
		System.out.println("Enter colors to Update :");
		name1=s1.nextLine();
		
		System.out.println("Enter position of colors to update :");
		pos=s1.nextInt();
		
		s.update(pos, name1);
		System.out.println("Updated list of colors is :");
		s.display();
		
		System.out.println("Enter Position of an colors elements to remove :");
		pos=s1.nextInt();
		s.remove(pos);
		System.out.println("Updated list of colors is :");
		s.display();
		
	

	}

}
