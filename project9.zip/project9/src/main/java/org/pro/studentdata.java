package org.pro;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;


@Path("getdata")
public class studentdata {

	@GET
	@Path("/add/{roll}/{name}/{age}/{address}")
	public String getXMLstudent(@PathParam("roll") int roll,@PathParam("name")String name,@PathParam("age") int age,@PathParam("address")String address)
	{
		Connection cn;
		Statement smt;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			
			smt.executeUpdate("insert into student3 values('"+roll+"','"+name+"','"+age+"','"+address+"')");
			
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return "data saved sucessfully";
		
	}
	
	@GET
	@Path("/delete/{roll}")
	public String deletedata(@PathParam("roll") int roll)
	{
		Connection cn;
		Statement smt;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			
			smt.executeUpdate("delete from student3 where roll =" +roll);
			
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return "data deleted successfully";
		
	}
	
	@GET
	@Path("/update/{roll}")
	public String updatedata(@PathParam("roll") int roll)
	{
		Connection cn;
		Statement smt;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			
			smt.executeUpdate("update student3 set address='hyderabad' where roll="+roll);
					
			
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return "data updated successfully";
		
	}
	
	@GET
	@Path("/show")
	public String updatedata()
	{
		Connection cn;
		Statement smt;
		ResultSet rs;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			
			rs=smt.executeQuery("select * from student3");
			
			
			while(rs.next())
			{
				System.out.println(" "+rs.getString("roll")+" "+rs.getString("name")+" "+rs.getString("age")+" "+rs.getString("address")+"");
			}
			
			
			rs.close();
			smt.close();
			cn.close();
			
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		return "data displayed successfully";
		
	}
}
