package org.pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class insertctl
 */
@WebServlet("/insertctl")
public class insertctl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insertctl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		  int roll=Integer.parseInt(request.getParameter("rn"));
		  String name=request.getParameter("nm");
		  int marks1=Integer.parseInt(request.getParameter("pm"));
		  int marks2=Integer.parseInt(request.getParameter("cm"));
		  int marks3=Integer.parseInt(request.getParameter("hm"));
		  int marks4=Integer.parseInt(request.getParameter("em"));
		  int marks5=Integer.parseInt(request.getParameter("m1"));
		  //double per=Integer.parseInt(request.getParameter("pn"));
		 
		  Connection cn;
		  Statement smt;
		  
		  
		  try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
				
				smt=cn.createStatement();
				
				
				double per=((marks1+marks2+marks3+marks4+marks5)/5);
				String grade;
				
				if(per>60 && per<70)
					grade="D GRADE";
				else if(per>70 && per<80)
					grade="C GRADE";
				else if(per>80 && per<90)
					grade="B GRADE";
				else if(per>90 && per<100)
					grade="A GRADE";
				else
					grade="fail";
				
				smt.executeUpdate("insert into students values("+roll+",'"+name+"',"+marks1+","+marks2+","+marks3+","+marks4+","+marks5+","+per+",'"+grade+"')");
				
					
				RequestDispatcher rd1=request.getRequestDispatcher("home2.jsp");
				
				rd1.forward(request, response);
				
				
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
		  	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
