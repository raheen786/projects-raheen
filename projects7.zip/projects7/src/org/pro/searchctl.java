package org.pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class searchctl
 */
@WebServlet("/searchctl")
public class searchctl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public searchctl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		 int roll=Integer.parseInt(request.getParameter("rn"));
		 // String name=request.getParameter("nm");
		  //int marks1=Integer.parseInt(request.getParameter("pm"));
		  //int marks2=Integer.parseInt(request.getParameter("cm"));
		  //int marks3=Integer.parseInt(request.getParameter("hm"));
		  //int marks4=Integer.parseInt(request.getParameter("em"));
		  //int marks5=Integer.parseInt(request.getParameter("m1"));
		 
		
		Connection cn;
		Statement smt;
		ResultSet rs;
		
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
            cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			
			rs=smt.executeQuery("select * from students where roll ="+roll);
			
			
			//out.print(rs.getString("d")+rs.getString("a")+rs.getString("b"));
			
			
			while(rs.next())
			{
				//out.print("congratulation");
				//out.print("<tr><td>"+rs.getString("roll")+"</td><td>"+rs.getString("name")+"</td><td> "+rs.getString("physics")+"</td><td>"+rs.getString("chemistry")+"</td><td>"+rs.getString("hindi")+"</td><td>"+rs.getString("english")+"</td><td>"+rs.getString("maths")+"</td></tr>"+rs.getString("percentage")+"</td></tr>");
				out.print("Roll :"+rs.getString("roll"));
				out.print("<br>");
				out.print("Name :"+rs.getString("name"));
				out.print("<br>");
				out.print("Physics Marks :"+rs.getString("physics"));
				out.print("<br>");
				out.print("Chemistry Marks :"+rs.getString("chemistry"));
				out.print("<br>");
				out.print("Hindi Marks :"+rs.getString("hindi"));
				out.print("<br>");
				out.print("English Marks :"+rs.getString("english"));
				out.print("<br>");
				out.print("Maths Marks :"+rs.getString("maths"));
				out.print("<br>");
				out.print("Percentage :"+rs.getString("percentage"));
				out.print("<br>");
				out.print("Grade :"+rs.getString("grade"));
			}
			
			//double per=rs.getString("percentage");
			
			
			rs.close();
			smt.close();
			cn.close();
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
